﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour {



    public static EnemyScript Instance;
    public GameObject parent;
    public GameObject Other;
    protected bool GrowthCalled = false;
    //Timer qui va gerer la Scale du Sprite jusqu'à ce que celle ci égale le player
    public float growthTime = 1.5f;
    public Vector3 Grownth = new Vector3(0.1f, 0.1f, 0.1f);
    protected bool FullyGrown;
    public int lifePoints = 1;
    //déplacement
    protected float timerIdle;
    protected Vector3 originalPosition;
    protected float Speed;
    [SerializeField] private float idledurationmin = 1;
    [SerializeField] private float idledurationMax = 5;
    [SerializeField] private float WanderingDistance = 6;
    Vector3? randomDestination;
    protected float oldManhattanDist;
    protected Vector3 currentPosition;
    protected bool facingRight = false;
    protected Animator Anim;
    public float cooldown = 2;
    protected Vector3 One;


    protected Vector3 LeftPosition;
    protected Vector3 RightPosition;
    protected enum State
    {
        Growing,
        Idle,
        Attacking,
    }

    public float randomAttack;
    public float randomAttackChance = 25;

    protected State state;


    protected State SetState(State truc)
    {
        return truc;
    }


    protected float timerAttack=0;
    public float timeAttack = 2;

    protected void Awake()
    {
        Instance = this;
    }
    // Use this for initialization
    protected void Start () {
        timerIdle = Random.Range(idledurationmin, idledurationMax);
        state = SetState(State.Growing);
        Anim = GetComponent<Animator>();
        originalPosition = transform.position;
        One = new Vector3(0.9f, 0.9f, 0.9f);
        
        if (parent.name == "EnemySpawnerRight")
        {
            RightPosition = parent.transform.position;
            LeftPosition = Other.transform.position;
        }

        else if (parent.name == "EnemySpawnerLeft")
        {
            LeftPosition = parent.transform.position;
            RightPosition = Other.transform.position;
        }
    }
	
	// Update is called once per frame
	protected void Update () {

        if (!GrowthCalled)
        {
            Growth();
        }

        if (transform.localScale == One)
        {
            FullyGrown = true;
            Anim.SetBool("Grown", FullyGrown);
            state = SetState(State.Idle);
        }


        if (timerIdle >= 0)
        {
            timerIdle -= Time.deltaTime;
            Move(0);

        }
        else
        {
            if (!randomDestination.HasValue)
            {
                float dist = Random.Range(originalPosition.x - WanderingDistance, originalPosition.x + WanderingDistance);
                randomDestination = new Vector3(dist, originalPosition.y, originalPosition.z);
                oldManhattanDist = (randomDestination.Value - transform.position).x;
            }

            var manhattanDist = (randomDestination.Value - transform.position).x;
            if (Mathf.Sign(manhattanDist) != Mathf.Sign(oldManhattanDist))
            {
                timerIdle = Random.Range(idledurationmin, idledurationMax);
                randomDestination = null;
                originalPosition = transform.position;
            }
            else
            {

                if (FullyGrown)
                {

                    randomAttack = Random.Range(0, 100);
                    Move(Mathf.Sign(manhattanDist));
                    timerAttack += 1 *Time.deltaTime;
                    
                        
                        if (randomAttack <= randomAttackChance && state!=State.Attacking)
                        {
                            attackPlayer();
                            timerAttack = 0;
                        }
                    
                }
                
                oldManhattanDist = manhattanDist;
            }
        }
    }


    void Growth()
    {
        if (!GrowthCalled)
        {
            GrowthCalled = true;
        }
        if (transform.localScale != One)
        {
            transform.localScale += Grownth;
        }

        Invoke("Growth", growthTime);
    }

    protected void Move(float distance)
    {
        currentPosition = transform.position;
        Speed = distance * Time.deltaTime;
        if (Anim.gameObject.activeSelf)
        {
            Anim.SetFloat("Speed", Mathf.Abs(distance));
        }

       
        transform.position = currentPosition + Vector3.right * Speed;
    }

    protected virtual void attackPlayer()
    {
        if (transform.position == RightPosition)
        {
            Anim.SetTrigger("PosOkLeft");
            state=SetState(State.Attacking);

        }

        else if (transform.position == LeftPosition)
        {
            Anim.SetTrigger("PosOkRight");
            state=SetState(State.Attacking);
        }

        GetComponentInChildren<AttackEnemy>().attack = true;
        Invoke("attackEnd", cooldown);
    }

    protected virtual void attackEnd()
    {
        GetComponentInChildren<AttackEnemy>().attack = false;
        state=SetState(State.Idle);
    }

    

    public void TakeDamages(float damages)
    {
        if (FullyGrown)
        {
            lifePoints--;
            if (lifePoints <= 0)
            {
                myDestroy();
            }
        }
        
    }

    protected virtual void myDestroy()
    {


        Anim.SetFloat("Life", 0);
        parent.gameObject.GetComponent<EnemySpawner>().spawnAlive = false;
        if (Other.GetComponent<EnemySpawner>().spawnAlive)
        {
            Other.GetComponent<EnemySpawner>().spawnAlive = false;
        }
        parent.gameObject.GetComponent<EnemySpawner>().spawnBoss--;
        Other.GetComponent<EnemySpawner>().spawnBoss--;


        Destroy(this.gameObject);


    }

    private void OnDestroy()
    {
        Instance = null;
    }
}
