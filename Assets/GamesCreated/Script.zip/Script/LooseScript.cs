﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LooseScript : MonoBehaviour {


    public Button Replay;
    public Button Quick;

	// Use this for initialization
	void Start () {
        Replay.onClick.AddListener(replay);
        Quick.onClick.AddListener(quit);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void replay()
    {
        SceneManager.LoadScene("FinalScene");

    }

    void quit()
    {
        Application.Quit();
    }
}
