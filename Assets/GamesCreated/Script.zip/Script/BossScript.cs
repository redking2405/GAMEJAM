﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BossScript : EnemyScript {

    public new static BossScript Instance;
    public bool Scale = false;



    //public Stat Health;
    //public GameObject BossBar;


    protected new void Awake()
    {
        Instance = this;
        //BossBar.gameObject.SetActive(true);
        //Health.Initialize();
        //base.Awake();
    }

	// Use this for initialization
	new void Start () {

        lifePoints = 25;
        
        //Health.MaxVal = 100;
        //Health.CurrentVal = 100;

        base.Start();
	}
	
	// Update is called once per frame
	new void Update () {
        base.Update();
	}


    protected void ReduceSpeed()
    {
        if (!FullyGrown)
        {
            this.gameObject.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
            FullyGrown = true;
            Invoke("ChangeLane", 2f);
        }

        
    }

    protected void ChangeLane()


    {

        if (transform.position == RightPosition)
        {
            Anim.SetFloat("Speed", LeftPosition.x - RightPosition.x);
            MoveLane(transform.position, LeftPosition.x - RightPosition.x, LeftPosition);
        }


        if (transform.position == LeftPosition)
        {
            Anim.SetFloat("Speed", RightPosition.x - LeftPosition.x);
        }

    }

    protected void MoveLane(Vector3 originalPosition, float Xspeed, Vector3 Destination)
    {
        if (originalPosition.x != Destination.x)
        {
            originalPosition.x += Xspeed;
        }


        if(originalPosition.x == Destination.x)
        {
            Invoke("GainingSpeed", 1f);
        }
    }

    protected void GainingSpeed()
    {
        if (FullyGrown)
        {
            this.gameObject.transform.localScale = new Vector3(1, 1, 1);
            FullyGrown = false;
           
        }
    }


    protected void OnDestroy()
    {
        SceneManager.LoadScene("WinScreen");
    }


}
