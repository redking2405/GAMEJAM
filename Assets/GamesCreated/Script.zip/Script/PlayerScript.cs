﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour {

    public static PlayerScript Instance;
	public bool left;
    public GameObject[] paths;
    public int CurrentRoad = 0;
    protected Animator Anim;
    public Stat Health;
    protected bool canBeHurt;
    public GameObject SpawnerRight;
    public GameObject SpawnerLeft;
    protected bool scale;
    protected Vector3 beginTouch;
    protected Vector3 endTouch;
    protected Vector3 swapDirection;



    void Awake()
    {
        Health.Initialize();
        Anim = GetComponent<Animator>();
        Instance = this;
    }
	// Use this for initialization
	void Start () {
        Health.CurrentVal = 100;
        Health.MaxVal = 100;
	}
	
	// Update is called once per frame
	void Update () {


        KeyboardInput();
        Swap();
        if (Input.GetMouseButton(0)==true)
        {
            attack();
        }

        if (Input.GetMouseButtonUp(0))
        {
            attackEnd();
        }

		

	}


    void KeyboardInput()
    {
        if ((Input.GetKeyDown(KeyCode.LeftArrow)) /*&& canSwap*/)
        {
            //canSwap = false;
            //isPressed = true;
            CurrentRoad--;
            if (CurrentRoad < 0)
            {
                CurrentRoad = 0;

            }

            movePlayer(SpawnerLeft.transform.position.x - SpawnerRight.transform.position.x, SpawnerLeft.transform.position.x);
            Debug.Log("je go à gauche");
        }
        if ((Input.GetKeyDown(KeyCode.RightArrow)) /*&& canSwap*/)
        {
            //canSwap = false;
            // isPressed = true;
            CurrentRoad++;
            if (CurrentRoad > 1)
            {
                CurrentRoad = 1;
            }

            movePlayer(SpawnerRight.transform.position.x - SpawnerLeft.transform.position.x, SpawnerRight.transform.position.x);
            Debug.Log("je go à droite");
        }

        if ((Input.GetKeyDown(KeyCode.UpArrow)) && !scale && transform.localScale==EnemyScript.Instance.transform.localScale)
        {
            scale = true;
            this.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
        }

        if (scale)
        {
            Invoke("Descale", 2);
        }

       




        // if(isPressed)
        // MoveCar(paths[CurrentRoad].transform);
    }

    public void Descale()
    {
        scale = false;
        transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
    }

    public void TakeDamages(float damages)
    {
        if (!Anim.GetBool("Hurt")||!Anim.GetBool("Dodging")&& canBeHurt&& !scale)
        {
            Health.CurrentVal -= damages;
            Anim.SetBool("Hurt", true);
            canBeHurt = false;
            Invoke("ReturnToLife", 2f);
        }

        if(Health.CurrentVal<=0)
        {
            Anim.SetFloat("Life", 0);
            SceneManager.LoadScene("LooseScreen");
            Destroy(this.gameObject);
        }

    }

    void Swap()
    {
            if (Input.GetMouseButtonDown(0))
            {
                beginTouch = Input.mousePosition;
            }

            if (Input.GetMouseButtonUp(0))
            {
                endTouch = Input.mousePosition;
                swapDirection = endTouch - beginTouch;
                beginTouch = Vector3.zero;
                endTouch = Vector3.zero;
                CheckSwapDirection();
            }
        

    }

    void CheckSwapDirection()
    {
        
        
        
        if (swapDirection.x > 0)
        {
            movePlayer(swapDirection.x, SpawnerRight.transform.position.x);
        }
        else if (swapDirection.x<0)
        {
            movePlayer(swapDirection.x, SpawnerLeft.transform.position.x);
        }

        if (swapDirection.y < 0)
        {
            scale = true;
            this.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
        }

        if (scale)
        {
            Invoke("Descale", 2);
        }

    }







    public void movePlayer(float speedX, float Destination)
    {
        if (transform.position.x != Destination)

        {
            Anim.SetFloat("Speed", speedX);
            transform.position = new Vector3(Destination, transform.position.y, transform.position.z);
        }

        if (transform.position.x == Destination)
        {
            Anim.SetFloat("Speed", 0);
        }
    }


    protected void ReturnToLife()
    {
        Anim.SetBool("Hurt", false);
        canBeHurt = true;
    }

    void attack()
    {
        GetComponentInChildren<AttackPlayer>().attack = true;
    }

    void attackEnd()
    {
        GetComponentInChildren<AttackPlayer>().attack = false;
    }

    private void OnDestroy()
    {
        Instance = null;
    }
}
