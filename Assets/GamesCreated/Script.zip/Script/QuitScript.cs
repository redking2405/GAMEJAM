﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class QuitScript : MonoBehaviour {


    public Button MyButton;
    public Button Mybutton;
    //public Button Replay;
    
    // Use this for initialization
	void Start () {
        MyButton.onClick.AddListener(OnClick);
        Mybutton.onClick.AddListener(Suivant);
    }
	
	// Update is called once per frame
	void Update () {
        
        
	}

    void OnClick()
    {
        Application.Quit();
    }

    void Suivant()
    {
        Debug.Log("Niveau Suivant");
    }
}
