﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour {


    public float time = 1.5f;   //Timer au bout duquel un enemi va repoper
    private float timer = 0;
    public int spawnBoss=4;     // Nombre d'ennemis qui doit poper avant le Boss

    //Prefab des Ennemis et du Boss à passer dans l'inspector Unity
    [SerializeField] protected GameObject Enemy1Prefab;  
    [SerializeField] protected GameObject Enemy2Prefab;
    [SerializeField] protected GameObject Enemy3Prefab;
    [SerializeField] protected GameObject BossPrefab;

    [SerializeField] protected EnemySpawner OtherSpawner;

    public bool hasBeenUsed; //bool qui teste si le spawner as spawné afin que les 2 spawner alternent

    public bool spawnAlive=false; // Check si l'enemi spawné est vivant afin de ne pas spawné à l'infini
    private float RandomChance; // Random number afin de changer la version de l'ennemi de base qui est spawné


	// Use this for initialization
	void Start () {
        if (hasBeenUsed)
        {
            spawnAlive = true;
        }
	}
	
	// Update is called once per frame
	void Update () {

        
        timer += 1 / Time.deltaTime;

        if (time <= timer)
        {

            if (!hasBeenUsed && !spawnAlive && BossScript.Instance == null && spawnBoss == 0 && EnemyScript.Instance==null)
            {
                SpawnBoss();

            }

            if (!hasBeenUsed && !spawnAlive && EnemyScript.Instance==null && spawnBoss!=0)
            {
                SpawnMob();

            }

            if (hasBeenUsed)
            {
                timer = 0;
            }

            



        }
	}

    //Spawneur de mob
    protected void SpawnMob()
    {
        RandomChance = Random.Range(0, 3);
        GameObject Enemy;
        if(0<=RandomChance && RandomChance < 1)
        {
            Enemy = Instantiate(Enemy1Prefab, transform.position, Quaternion.identity);
            spawnAlive = true;
            Enemy.transform.localScale = transform.localScale;
            Enemy.GetComponent<EnemyScript>().parent = this.gameObject;
            Enemy.GetComponent<EnemyScript>().Other = OtherSpawner.gameObject;
            OtherSpawner.hasBeenUsed = false;
        }

        else if(1<=RandomChance && RandomChance < 2)
        {
            Enemy = Instantiate(Enemy2Prefab, transform.position, Quaternion.identity);
            spawnAlive = true;
            Enemy.transform.localScale = transform.localScale;
            Enemy.GetComponent<EnemyScript>().parent = this.gameObject;
            Enemy.GetComponent<EnemyScript>().Other = OtherSpawner.gameObject;
            OtherSpawner.hasBeenUsed = false;
        }

        else if(2<=RandomChance && RandomChance <= 3)
        {
            Enemy = Instantiate(Enemy3Prefab, transform.position, Quaternion.identity);
            spawnAlive = true;
            Enemy.transform.localScale = transform.localScale;
            Enemy.GetComponent<EnemyScript>().parent = this.gameObject;
            Enemy.GetComponent<EnemyScript>().Other = OtherSpawner.gameObject;
            OtherSpawner.hasBeenUsed = false;
        }

        hasBeenUsed = true;
        timer = 0;
        
    }

    protected void SpawnBoss()
    {
        GameObject Boss= Instantiate(BossPrefab, transform.position,Quaternion.identity);
        spawnAlive = true;
        Boss.transform.localScale = transform.localScale;
        Boss.GetComponent<BossScript>().parent = this.gameObject;
        Boss.GetComponent<BossScript>().Other = OtherSpawner.gameObject;
        OtherSpawner.hasBeenUsed = false;
    }
}
