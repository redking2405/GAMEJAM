﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackPlayer : MonoBehaviour {

	public bool attack=false;
    public int damages = 10;


	// Use this for initialization
	void Start () {

        
		
	}
	
	// Update is called once per frame
	void Update () {


	}

    private void OnTriggerStay2D(Collider2D collision)
    {
        if(collision.gameObject.layer==11 && attack && collision.gameObject.tag!="BOSS")
        {

            EnemyScript.Instance.TakeDamages(damages);
           
        }

        if (collision.gameObject.tag == "BOSS" && attack && collision.gameObject.layer==11)
        {
            BossScript.Instance.TakeDamages(damages);
        }
    }
}
